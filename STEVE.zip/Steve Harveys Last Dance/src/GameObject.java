
public abstract class GameObject 
{
	protected int x, y;

}
